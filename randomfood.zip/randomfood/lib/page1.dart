import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';

class Page1 extends StatelessWidget {
  const Page1({super.key});

  @override
  Widget build(BuildContext context) {
    final foodCategories = [
      {
        'title': '한식',
        'image': 'assets/images/bop.png',
      },
      {
        'title': '중식',
        'image': 'assets/images/yang.png',
      },
      {
        'title': '일식',
        'image': 'assets/images/chicken.png',
      },
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFF0F0F0),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(top: 40.0, left: 8, right: 8, bottom: 24),
          child: Column(
            children: [
              CarouselSlider.builder(
                itemCount: foodCategories.length,
                itemBuilder: (context, index, realIndex) {
                  final item = foodCategories[index];
                  return Card(
                    color: Colors.white,
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      children: [
                        Expanded(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(30),
                            child: item['image']!.startsWith('http')
                                ? Image.network(
                              item['image']!,
                              fit: BoxFit.fitWidth,
                              width: double.infinity,
                              errorBuilder: (context, error, stackTrace) {
                                return const Center(
                                    child: Icon(Icons.broken_image, size: 20));
                              },
                            )
                                : Image.asset(
                              item['image']!,
                              fit: BoxFit.fitWidth,
                              width: double.infinity,
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          item['title']!,
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF333333),
                          ),
                        ),
                        const SizedBox(height: 6),
                      ],
                    ),
                  );
                },
                options: CarouselOptions(
                  height: 180,
                  enlargeCenterPage: true,
                  autoPlay: true,
                  autoPlayInterval: const Duration(seconds: 4),
                  viewportFraction: 1.0,
                ),
              ),
              const SizedBox(height: 30),
              IntrinsicHeight(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.lightGreen.shade100,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.shade300.withOpacity(0.6),
                              blurRadius: 8,
                              offset: const Offset(0, 4),
                            )
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween, // 중요
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                Text(
                                  '공지사항',
                                  style: TextStyle(
                                    fontSize: 30,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.lightGreen,
                                  ),
                                ),
                                SizedBox(height: 8),
                                Text(
                                  '''- 새로운 음식 카테고리가 곧 추가됩니다!
- 앱 버전 1.1 업데이트 완료
- 서버 점검 안내: 6월 5일 오후 10시부터
- 공지사항은 주기적으로 업데이트됩니다.
- 테스트 항목 5
- 테스트 항목 6
- 테스트 항목 7
- 테스트 항목 8
''',
                                  style: TextStyle(fontSize: 18),
                                ),
                              ],
                            ),
                            InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => const FullNoticePage()),
                                );
                              },
                              child: const Text(
                                '전체 공지 보기',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black87,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.lightBlue.shade100,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.shade300.withOpacity(0.6),
                              blurRadius: 8,
                              offset: const Offset(0, 4),
                            )
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween, // 중요
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                Text(
                                  '이벤트',
                                  style: TextStyle(
                                    fontSize: 30,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.lightBlue,
                                  ),
                                ),
                                SizedBox(height: 8),
                                Text(
                                  '''- 배민 쿠폰 50% 할인 이벤트 진행중!
- 친구 초대하면 추가 쿠폰 증정!
- 이번 달 추천 음식 맞추기 이벤트 참여하세요!
- 매주 추첨을 통해 상품 증정!
- 추가 이벤트 항목 5
- 추가 이벤트 항목 6
- 추가 이벤트 항목 7
- 추가 이벤트 항목 8
''',
                                  style: TextStyle(fontSize: 18),
                                ),
                              ],
                            ),
                            InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => const EventDetailPage()),
                                );
                              },
                              child: const Text(
                                '이벤트 상세보기',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black87,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// 임시 전체 공지 페이지 예시
class FullNoticePage extends StatelessWidget {
  const FullNoticePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('전체 공지')),
      body: const Center(
        child: Text('여기에 전체 공지 내용이 들어갑니다.'),
      ),
    );
  }
}

// 임시 이벤트 상세 페이지 예시
class EventDetailPage extends StatelessWidget {
  const EventDetailPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('이벤트 상세')),
      body: const Center(
        child: Text('여기에 이벤트 상세 내용이 들어갑니다.'),
      ),
    );
  }
}