import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:table_calendar/table_calendar.dart';
import 'shared_state.dart';

class Page3 extends StatelessWidget {
  const Page3({super.key});

  @override
  Widget build(BuildContext context) {
    final sharedState = context.watch<SharedState>();

    // 출석 날짜 변환 (yyyy-MM-dd → DateTime)
    final attendanceDates = sharedState.recommendDates.map((d) {
      final parts = d.split('-');
      return DateTime(
        int.parse(parts[0]),
        int.parse(parts[1]),
        int.parse(parts[2]),
      );
    }).toSet();

    final favorites = sharedState.favoriteFoods;
    final coupons = sharedState.couponList;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 출석 달력
          Container(
            decoration: BoxDecoration(
              color: Colors.grey[100],
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey.shade300),
            ),
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("📅 출석 기록", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                TableCalendar(
                  firstDay: DateTime.now().subtract(const Duration(days: 365)),
                  lastDay: DateTime.now().add(const Duration(days: 365)),
                  focusedDay: DateTime.now(),
                  calendarFormat: CalendarFormat.month,
                  availableGestures: AvailableGestures.horizontalSwipe,
                  headerStyle: HeaderStyle(
                    formatButtonVisible: false,  // 이 부분 추가: 포맷 변경 버튼 숨기기
                  ),
                  calendarBuilders: CalendarBuilders(
                    defaultBuilder: (context, day, focusedDay) {
                      final date = DateTime(day.year, day.month, day.day);
                      if (attendanceDates.contains(date)) {
                        return Container(
                          margin: const EdgeInsets.all(6),
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.orangeAccent,
                          ),
                          child: Center(
                            child: Text(
                              '${day.day}',
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                            ),
                          ),
                        );
                      }
                      return null;
                    },
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          // 즐겨찾기 섹션
          _section(
            "⭐ 즐겨찾기한 음식",
            favorites.isNotEmpty
                ? favorites.map((f) => "• $f").toList()
                : ["• 즐겨찾기한 음식이 없습니다."],
          ),

          const SizedBox(height: 20),

          // 쿠폰 섹션
          _section(
            "🎁 보유 쿠폰",
            coupons.isNotEmpty
                ? coupons.map((c) => "- $c").toList()
                : ["- 아직 보유한 쿠폰이 없습니다."],
          ),
        ],
      ),
    );
  }

  Widget _section(String title, List<String> items) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ...items.map((text) => Text(text, style: const TextStyle(fontSize: 16))),
        ],
      ),
    );
  }
}
