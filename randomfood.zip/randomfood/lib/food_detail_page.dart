import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'shared_state.dart';

class FoodDetailPage extends StatefulWidget {
  final String categoryTitle;
  final VoidCallback? onRetry;

  const FoodDetailPage({
    super.key,
    required this.categoryTitle,
    this.onRetry,
  });

  @override
  State<FoodDetailPage> createState() => _FoodDetailPageState();
}

class _FoodDetailPageState extends State<FoodDetailPage> {
  bool _revealed = false;
  int _currentIndex = 0;

  final Map<String, Map<String, String>> tempFoodDetails = {
    '김치찌개': {
      'image': 'assets/images/kimchi.png',
      'description': '얼큰하고 깊은 맛의 김치찌개!'
    },
    '비빔밥': {
      'image': 'assets/images/bibimbap.png',
      'description': '채소와 고추장의 조화로운 만남!'
    },
  };

  void _revealCard() {
    setState(() => _revealed = true);
  }

  void _nextCard(SharedState state) {
    if (_currentIndex < state.selectedFoods.length - 1) {
      setState(() {
        _currentIndex++;
        _revealed = false;
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('선택한 모든 추천을 확인했어요!'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final sharedState = context.watch<SharedState>();
    final foods = sharedState.selectedFoods;
    final food = foods[_currentIndex];
    final foodInfo = tempFoodDetails[food];
    final imagePath = foodInfo?['image'] ?? 'assets/images/default.png';
    final description = foodInfo?['description'] ?? '이 음식은 정말 맛있고 건강에 좋아요!';
    final isFavorite = sharedState.favoriteFoods.contains(food);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.categoryTitle),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              if (sharedState.canRetry) {
                widget.onRetry?.call();
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('선택한 횟수만큼 모두 추천을 받았어요!'),
                  ),
                );
              }
            },
          ),
        ],
      ),
      body: Center(
        child: !_revealed
            ? GestureDetector(
          onTap: _revealCard,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            width: 250,
            height: 300,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              image: const DecorationImage(
                image: AssetImage('assets/images/gacha_machine.png'), // 실제 파일명에 맞게 교체 필요
                fit: BoxFit.cover,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 12,
                  offset: const Offset(0, 6),
                )
              ],
            ),
          ),
        )
            : Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset(
                imagePath,
                width: 120,
                height: 120,
                fit: BoxFit.cover,
              ),
              const SizedBox(height: 24),
              Text(
                food,
                style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              Text(
                description,
                style: const TextStyle(fontSize: 16),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                icon: Icon(isFavorite ? Icons.favorite : Icons.favorite_border),
                label: Text(isFavorite ? '즐겨찾기 해제' : '즐겨찾기 추가'),
                onPressed: () {
                  if (isFavorite) {
                    sharedState.removeFavorite(food);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('$food 즐겨찾기에서 제거됨')),
                    );
                  } else {
                    sharedState.addFavorite(food);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('$food 즐겨찾기에 추가됨')),
                    );
                  }
                },
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () => _nextCard(sharedState),
                child: const Text('다음 추천 보기'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
